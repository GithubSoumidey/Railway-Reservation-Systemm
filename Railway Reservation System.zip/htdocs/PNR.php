<?php
//session_start();
require('dbconfig.php');
require('firstimport.php');

$tbl_name="interlist";

 

?>
<!DOCTYPE html>
<html>
<head>
	<title> Find Train </title>
	<link rel="shortcut icon" href="images/favicon.png"></link>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	</link>
	<link href="css/Default.css" rel="stylesheet">
	</link>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script>
		$(document).ready(function()
		{
			var x=(($(window).width())-1024)/2;
			$('.wrap').css("left",x+"px");
		});

	</script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/man.js"></script>
	
</head>
<body>
	<div class="wrap">
		<!-- Header -->
		<div class="header">
			<div style="float:left;width:150px;">
				<img src="images/logo.png"/>
			</div>		
			<div>
			<div style="float:right; font-size:20px;margin-top:20px;">
			<?php
			 if(isset($_SESSION['name']))
			 {
			 echo "Welcome,".$_SESSION['name']."&nbsp;&nbsp;&nbsp;<a href=\"logout.php\" class=\"btn btn-info\">Logout</a>";
			 }
			 ?>
			
			</div>
			<div id="heading">
				<a href="#">Railway Reservation</a>
			</div>
			</div>
		</div>
		<div class="navbar navbar-inverse" >
			<div class="navbar-inner">
				<div class="container" >
				<a class="brand" href="index.php" >HOME</a>
				<a class="brand" href="about.php" >ABOUT</a>
				<!-- <a class="markit" href="PNR.php" >PNR ENQUIRY</a> -->
				<a class="brand" href="train.php" >FIND TRAIN</a>
				<a class="brand" href="reservation.php">RESERVATION</a>
				<a class="brand" href="profile.php">PROFILE</a>
				<a class="brand" href="booking_h.php">BOOKING HISTORY</a>
				<a class="brand" href="Help.php" >CONTACT US</a>
				</div>
			</div>
		</div>
		
		<div class="span12 well" id="boxh">
		
			<form style="margin:0px;" method="post" >
			<table class="table" style="margin-bottom:0px;">
				<tr>
					<th style="border-top:0px;"><label><b>Enter PNR Number</label></th>
					
					<td style="border-top:0px;"><input id="xbox1" type="text" class="input-block-level" name="pnr" ></td>
					<td style="border-top:0px;"><input class="btn btn-info" name="submit" type="submit" value="Submit"> </td>
						</tr>
			</table>
			</form>
		</div>
<!-- display result --><?php
if(isset($_POST['submit']))
{
	
	$pnr=$_POST['pnr'];
	//$from=strtoupper($from);
	//$to=strtoupper($to);
	$sql="SELECT * FROM `booking` WHERE PNR='$pnr'";
	$result=select($sql);
while($r=	mysqli_fetch_array($result))
{
	?>
	<div class="span12 well">
			<div class="display" >
				<table class="table" border="5px">
				<tr>
					<th style="width:70px;border-top:0px;"> username</th>
					<th style="width:210px;border-top:0px;"> Train Number</th>
					<th style="width:65px;border-top:0px;"> Class </th>
					<th style="width:55px;border-top:0px;"> From </th>
					<th style="width:60px;border-top:0px;"> To</th>
					<th style="width:65px;border-top:0px;"> Name</th>
					<th style="width:20px;border-top:0px;"> Status</th>
					</tr>
					<tr>
					<th style="width:70px;border-top:0px;"> <?=$r['uname']?></th>
					<th style="width:210px;border-top:0px;"> <?=$r['Tnumber']?></th>
					<th style="width:65px;border-top:0px;">  <?=$r['class']?></th>
					<th style="width:55px;border-top:0px;"> <?=$r['fromstn']?></th>
					<th style="width:60px;border-top:0px;">  <?=$r['tostn']?></th>
					<th style="width:65px;border-top:0px;">  <?=$r['Name']?></th>
					<th style="width:20px;border-top:0px;">  <?=$r['Status']?></th>
					</tr>
				</table>
			</div>
			
			</div>
		</div>
	<?php
}
	
}

	?>

	
		<footer >
		<div style="width:100%;">
			<div style="float:left;">
			<p class="text-right text-info">The Calcutta Technical School 2020-2021</p>	
			</div>
			<div style="float:right;">
			<p class="text-right text-info">	Desinged By : <a href="#">Salini,Sumit,Deb,Soumyadeep,Soumi,Manoj</a></p>
			</div>
		</div>
		</footer>	</div>
</body>
</html>