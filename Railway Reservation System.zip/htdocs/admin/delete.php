<?php
include"dbconfig.php";
echo $n=iud("DELETE FROM `train_list` WHERE Number='".$_REQUEST['id']."'");
if($n==1)
{
	echo'<script>alert("Delete Successful");
	window.location="tables.php";
	</script>';
}
?>