<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
	<title> Railway Reservation</title>
	<link rel="shortcut icon" href="images/favicon.png">
	</link>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	</link>
	<link href="css/bootstrap.css" rel="stylesheet">
	</link>
	<link href="css/Default.css" rel="stylesheet">
	</link>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script>
		$(document).ready(function() {
			var x = (($(window).width()) - 1024) / 2;
			$('.wrap').css("left", x + "px");
		});
	</script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/man.js"></script>
</head>

<body>

	<div class="wrap">
		<!-- Header -->
		<div class="header">
			<div style="float:left;width:150px;">
				<img src="images/logo.png" />
			</div>
			<div>
				<div style="float:right; font-size:20px;Color:white;margin-top:20px;">

					<?php
					//print_r($_SESSION);
					if (isset($_SESSION['name'])) {
						echo "Welcome," . $_SESSION['name'] . "&nbsp;&nbsp;&nbsp;<a href=\"logout.php\" class=\"btn btn-info\">Logout</a>";
					} else {
					?>
						<!-- <a href="login1.php" class="btn btn-info">Login</a>&nbsp;&nbsp;&nbsp;&nbsp; -->
						<!-- <a href="signup.php?value=0" class="btn btn-info">Signup</a> -->
					<?php } ?>


				</div> 
				<div id="heading">
					<a href="#">Railway Reservation</a>
				</div>
			</div>
		</div>

		<!-- Navigation bar -->
		<div class="navbar navbar-inverse">
			<div class="navbar-inner">
				<div class="container">
					<a class="brand" href="index.php">HOME</a>
					<a class="markit" href="ABOUT.php">ABOUT</a>
					<a class="brand" href="train.php">FIND TRAIN</a>
					<a class="brand" href="reservation.php">RESERVATION</a>
					<a class="brand" href="profile.php">PROFILE</a>
					<a class="brand" href="booking_h.php">BOOKING HISTORY</a>
					<a class="brand" href="Help.php">CONTACT US</a>
				</div>
			</div>
		</div>
		<div class="span12 well">
			<section>
				<div class="sect">
					<div class="heading">
						<h1 style="color:BLUE">RAILWAY RESERVATION SYSTEM </h1>
						<h4 style="color:navy">Should be able to manage all the reservation related functions. The system should be distributed in
							nature. This system is divided into five zones.
							<br> North Zone
							<br>South Zone
							<br>East Zone
							<br>West Zone
							<br>Central Zone
							<br>
							Each zone should have same functionalities. Each zone will stores the information about train name,
							train schedules, availability. The administrator should be able to enter any change related to the
							train information like change in train name, number etc. The system should be able to reserve seat
							in a train for a passenger. First the clerk will check for availability for the seats in a
							particular train on a specified date of journey. If it is available the clerk will reserve seats.
							The system should be able to cancel a reservation. The clerk will delete the entries in the system. The system will display his current status like confirmed. 
						</h4>
					</div>
					<div class="box;color:BLUE">
						<h1 style="color:BLUE"><U>STATION INFORMATION</U></h1>
						<style>
							table {
								font-family: arial, sans-serif;
								border-collapse: collapse;
								width: 100%;
							}

							td,
							th {
								border: 1px solid #dddddd;
								text-align: left;
								padding: 8px;
							}

							tr:nth-child(even) {
								background-color: #dddddd;
							}
						</style>
						</head>

						<body>

							<table>
								<tr>
									<th style="color:GREEN"><U> STATION NAME</th>
									<th style="color:ORANGE"><U> STATION CODE </H4>
									</th>
								</tr>
								<tr>
									<td>&nbsp AGARTALA</td>
									<td>&nbsp AGTL</td>
								</tr>
								<tr>
									<td>&nbsp AMRITSAR</td>
									<td>&nbsp ASR</td>
								</tr>
								<tr>
									<td>&nbsp CHHATRAPATI SHIVAJI MAHARAJ TERMINUS</td>
									<td>&nbsp CSMT</td>
								</tr>
								<tr>
									<td>&nbsp DHANBAD</td>
									<td>&nbsp DHN</td>
								</tr>
								<tr>
									<td>&nbsp DIBRUGARH</td>
									<td>&nbsp DBRG</td>
								</tr>
								<tr>
									<td>&nbsp GUWHATI</td>
									<td>&nbsp GHY</td>
								</tr>
								<tr>
									<td>&nbsp HOWRAH</td>
									<td> &nbsp HWH</td>
								</tr>
								<tr>
									<td>&nbsp SEALDAH</td>
									<td> &nbsp SDAH</td>
								</tr>
								<tr>
									<td>&nbsp KALKA</td>
									<td>&nbsp KLK</td>
								</tr>
								<tr>
									<td>&nbsp KOLKATA</td>
									<td>&nbsp KOAA</td>
								</tr>
								<tr>
									<td>&nbsp MADGOAN (GOA)</td>
									<td>&nbsp MAO</td>
								</tr>
								<tr>
									<td>&nbsp MGR CHENNAI CENTRAL</td>
									<td>&nbsp MAS</td>
								</tr>
								<tr>
									<td>&nbsp MUMBAI CENTRAL</td>
									<td>&nbsp BCT</td>
								</tr>
								<tr>
									<td>&nbsp NEW DELHI</td>
									<td>&nbsp NDLS</td>
								</tr>
								<tr>
									<td>&nbsp PATNA JUNCTION</td>
									<td>&nbsp PNBE</td>
								</tr>
								<tr>
									<td>&nbsp PURI</td>
									<td>&nbsp PURI</td>
								</tr>
								<tr>
									<td>&nbsp SANTRAGACHI</td>
									<td>&nbsp SRC</td>
								</tr>
								<tr>
									<td>&nbsp UDHAMPUR</td>
									<td>&nbsp UHP</td>
								</tr>
								<tr>
									<td>&nbsp YESVANTAPURE</td>
									<td>&nbsp YPR</td>
								</tr>	
								<tr>
									<td>&nbsp </td>
									<td>&nbsp </td>
								</tr>
							</table>
							</table>

					</div>
				</div>
			</section>
			<div>
				<div>

					<div>
					</div>
				</div>
			</div>

			<!-- Copyright -->
			<footer>
				<div style="width:100%;">
					<div style="float:left;">
						<p class="text-right text-info">The Calcutta Technical School 2020-2021</p>
					</div>
					<div style="float:right;">
						<p class="text-right text-info"> Desinged By : <a href="#">Salini,Sumit,Deb,Soumyadeep,Soumi,Manoj</a></p>
					</div>
				</div>
			</footer>
		</div>

</body>

</html>

<?php

if (isset($_SESSION['error'])) {
	session_destroy();
}

?>