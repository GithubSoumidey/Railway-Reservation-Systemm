<?php
	//session_start();
	
require('dbconfig.php');
require('firstimport.php');
if(isset($_SESSION['name'])){}
	else{
		header("location:login1.php");
		
	}

$name1=$_SESSION['name'];

?>




<!DOCTYPE html>
<html lang="en">

<head>
<title> Reservation </title>
	<link rel="shortcut icon" href="images/favicon.png"></link>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	</link>
	<link href="css/Default.css" rel="stylesheet">
	</link>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script>
		$(document).ready(function()
		{
			var x=(($(window).width())-1024)/2;
			$('.wrap').css("left",x+"px");
		});

	</script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/man.js"></script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Bare - Start Bootstrap Template</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
	<div class="wrap">
		<div class="header">
			<div style="float:left;width:150px;">
				<img src="images/logo.png"/>
			</div>		
			<div>
			<div style="float:right; font-size:20px;Color:white;margin-top:20px;">
			<?php
			 if(isset($_SESSION['name']))
			 {
			 echo "Welcome,".$_SESSION['name']."&nbsp;&nbsp;&nbsp;<a href=\"logout.php\" class=\"btn btn-info\">Logout</a>";
			 }
			 ?>
			
			</div>
			<div id="heading">
				<a href="index.php">Railway Reservation</a>
			</div>
			</div>
		</div>
		<!-- Navigation bar -->
		<div class="navbar navbar-inverse" >
			<div class="navbar-inner">
				<div class="container" >
				<a class="brand" href="index.php" >HOME</a>
				<a class="brand" href="about.php" >ABOUT</a>
				<a class="brand" href="train.php" >FIND TRAIN</a>
				<a class="brand" href="reservation.php">RESERVATION</a>
				<a class="brand" href="profile.php">PROFILE</a>
				<a class="brand" href="booking_h.php">BOOKING HISTORY</a>
				</div>
			</div>
		</div>
		
		<div class="span12 well">
			<div align="center" style="border-bottom: 3px solid #ddd;">
				<h2>ANY REASON For CANCELLATION  </h2>
		
		<form method="post">
<input type="hidden" name="name" value="<?=$_REQUEST['name']?>">
<input type="hidden" name="age" value="<?=$_REQUEST['age']?>">
		<textarea name="reason">
		Type here...
		</textarea></br>
		<input type="submit" name="submit" class="btn btn-success">
		</form>
			</div>
			<?php
			
			if(isset($_REQUEST['submit']))
			{
				extract($_REQUEST);
			$query="UPDATE `booking` SET `cancel`=b'1' , `reason`='$reason' WHERE Name='$name' and Age='$age'";
	$n=iud($query);
	
			if($n>=1)
			{
				echo'<script>alert("CANCELLATION SUCCESSFUL")</script>';
				header("location:booking_h.php");
			}
			else
			{
				echo "Something Wrong ";
				header("location:booking_h.php");
			}
			}
			
			
			
		
			
			
			
			?>
			
			<br>
			<!--
			<div >
				<table class="table">
				
				<tr>
					<th style="border-top:0px;" > <label>Train No.<label></th>
					<td style="border-top:0px;"><label class="text-error"><?php echo $tnum;?></label></td>
					<th style="border-top:0px;"><label> Train Name<label> </th>
					<td style="border-top:0px;"><label class="text-error"><?php echo $tname;?></label></td>
					<th style="border-top:0px;"> <label>Class <label></th>
					<td style="border-top:0px;"><label class="text-error"><?php echo $cl;?></label></td>	
					
				</tr>
				</table>
			</div>
			-->
			<div>
			
			</div>
			
		</div>
			
		<!-- Copyright -->
		<footer >
		<div style="width:100%;">
			<div style="float:left;">
			<p class="text-right text-info">The Calcutta Technical School 2020-2021</p>	
			</div>
			<div style="float:right;">
			<p class="text-right text-info">	Desinged By : <a href="#">Salini,Sumit,Deb,Soumyadeep,Soumi,Manoj</a></p>
			</div>
		</div>
		</footer>
	</div>













  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
